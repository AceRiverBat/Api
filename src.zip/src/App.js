import logo from './logo.svg';
import './App.css';
import Api from './Api';
import ProduitList from './ProduitList';

function App() {
  return (
<h1>HELLO</h1>
  );
}

export default App;
