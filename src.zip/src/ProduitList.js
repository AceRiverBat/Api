import React from 'react';
import './App.css';
import axios, { Axios } from 'axios';
import Api from './Api';
 
class ProduitList extends React.Component {
 
state = {
  apiResponse:[]
}
componentDidMount() {
        
  const url = 'http://127.0.0.1:8000/api/produits';

  fetch(url)
      .then(res => res.json())
      .then(json => {
          this.setState({
              isLoaded: true,
              items: json,
          })
      });
   
}
  render() {
    return (
      <div>
      <p>TEST</p>
      <p>{ Api.) }</p>
      </div>
    );
  }
}
export default ProduitList;